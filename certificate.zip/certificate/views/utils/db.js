
const MONGO_URI ="mongodb+srv://saumya1294be21:72owkavPy9l1d211@cluster0.gscjdey.mongodb.net/certificateGenerator?retryWrites=true&w=majority";
const mongoose = require("mongoose");
const connectDb = async () =>{
    try {
        const conn = await mongoose.connect(MONGO_URI);
        console.log(`Database connect hogya: ${conn.connection.host}`);

    } catch (error) {
        console.error("database connect nhi hua");
        process.exit(0);
    }
};

module.exports=connectDb;


